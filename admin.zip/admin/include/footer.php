<footer>
  <p>&copy; 2020 - Musée Alix Pelletier</p>
</footer>

</body>
</html>
