<?php
require "admin.php";

ftruncate($fichier,0);
