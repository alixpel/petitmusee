<?php
session_start();

if(
    isset($_POST["email"]) &&
    isset($_POST["password"]) &&
    $_POST["email"] == "admin@map.com" &&
    $_POST["password"] == "php2020"
    ) {
    $_SESSION["a_le_droit_de_se_connecter"] == TRUE;
    $_SESSION["emailadmin"] = $_POST["email"];
    header ("location:admin.php");

} else {
    header ("location:connexion.php");
};



$nomChampsObligatoires = array("email", "password");

foreach($nomChampsObligatoires as $nomChamp) {

    if( empty($_POST[$nomChamp])) {

        $_SESSION["err"] = "CHAMP";
        $_SESSION["champ_erreur"] =  $nomChamp;

        header("location:connexion.php");
        exit;

    }
}

include("admin.php");

?>
